<?php

global $sugar_config, $db;
$sugar_config['default_max_tabs'] = 10;
$sugar_config['suitecrm_version'] = '7.10.4';
$sugar_config['email_enable_auto_send_opt_in'] = true;
$sugar_config['email_enable_confirm_opt_in'] = 'not-opt-in';

ksort($sugar_config);
write_array_to_file('sugar_config', $sugar_config, 'config.php');

