ALTER TABLE email_addresses
ADD confirm_opt_in VARCHAR(255) DEFAULT 'opt-in' NULL;

ALTER TABLE email_addresses
ALTER COLUMN confirm_opt_in SET DEFAULT 'not-opt-in';